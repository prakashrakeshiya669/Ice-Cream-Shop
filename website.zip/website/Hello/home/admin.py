from django.contrib import admin
from home.models import Contact
from home.models import Offline
from home.models import Service

# Register your models here.
admin.site.register(Contact)
admin.site.register(Offline)
admin.site.register(Service)




